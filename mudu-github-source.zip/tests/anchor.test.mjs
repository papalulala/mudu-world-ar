import assert from 'node:assert/strict';
import {SpatialPlacement} from '../dist/anchor-state.mjs';
import {Vector3,Quaternion,PerspectiveCamera,Group} from '../dist/vendor/three.module.js';
import fs from 'node:fs/promises';
const config=JSON.parse(await fs.readFile(new URL('../dist/assets/world-config.json',import.meta.url)));
const detail={name:config.targetName,position:{x:1,y:1.8,z:-2},rotation:{x:0,y:0,z:0,w:1},scale:1,scaledWidth:.75,scaledHeight:1};
const placement=new SpatialPlacement(config);
for(let i=0;i<30;i++)assert.equal(placement.ingest(detail,i*80,false),false,'image detection alone must not lock without normal SLAM tracking');
assert.equal(placement.locked,false);
placement.reset();
for(let i=0;i<12;i++)placement.ingest(detail,i*90,true);
assert.equal(placement.locked,true,'a stable image pose with valid world tracking must lock');
const before=placement.pose.position.toArray();const beforeRotation=placement.pose.rotation.toArray();
placement.markerLost();assert.equal(placement.markerVisible,false);assert.equal(placement.locked,true);
assert.deepEqual(placement.pose.position.toArray(),before,'losing the image must preserve the world anchor');
placement.ingest({...detail,position:{x:50,y:30,z:10}},3000,true);
assert.deepEqual(placement.pose.position.toArray(),before,'reacquiring or moving the marker must not drag a locked panel');
assert.deepEqual(placement.pose.rotation.toArray(),beforeRotation);
const board=new Group();board.position.copy(placement.pose.position);board.quaternion.copy(placement.pose.rotation);board.updateMatrixWorld();
const world=board.matrixWorld.toArray();const camera=new PerspectiveCamera(50,1.3,.01,100);camera.position.set(0,2,1);camera.lookAt(board.position);camera.updateMatrixWorld();
const pointA=board.position.clone().project(camera);camera.position.x+=1;camera.lookAt(board.position.clone().add(new Vector3(.3,0,0)));camera.updateMatrixWorld();const pointB=board.position.clone().project(camera);
assert.notDeepEqual(pointA.toArray(),pointB.toArray(),'moving the camera must change the view of the board');
assert.deepEqual(board.matrixWorld.toArray(),world,'camera movement must not move the world anchor');
placement.reset();assert.equal(placement.locked,false);assert.equal(placement.pose,null);
placement.ingest({...detail,scale:0},0,true);assert.equal(placement.samples,0,'invalid target poses must not lock');
console.log('PASS: stable lock, no lock without SLAM, persistence after marker loss, no marker-follow after lock, camera perspective, reset, invalid input');

const {MultiImagePlacement}=await import('../dist/anchor-state.mjs');
const multi=new MultiImagePlacement(config);
for(const t of config.targets){
 multi.reset();const d={...detail,name:t.targetName};
 for(let i=0;i<12;i++)multi.ingest(d,i*90,true);
 assert.equal(multi.locked,true,`${t.targetName} must lock`);
 const fixed=multi.pose.position.toArray();
 const other=config.targets.find(x=>x.targetName!==t.targetName);
 multi.ingest({...d,name:other.targetName,position:{x:99,y:99,z:99}},2000,true);
 multi.markerLost(t.targetName);
 assert.deepEqual(multi.pose.position.toArray(),fixed,'other image and image loss must preserve lock');
}
multi.reset();multi.ingest(detail,0,true);
multi.markerLost('mudu-poster');assert.equal(multi.samples,1,'unrelated image loss must not reset active image');
multi.ingest({...detail,name:'mudu-poster'},90,true);assert.equal(multi.samples,1,'switching images must restart stability samples');
console.log('PASS: both image targets, independent stability, first stable image keeps world anchor');

const {createBirdDecoration}=await import('../dist/bird-decoration.mjs');
const birdData=JSON.parse(await fs.readFile(new URL('../dist/assets/white-bird.json',import.meta.url)));
const decorations=createBirdDecoration(birdData,config.imageAspect);const bird=decorations.children[0];
const {Box3}=await import('../dist/vendor/three.module.js');
const bounds=new Box3().setFromObject(bird);assert.ok(Math.abs(bounds.max.x-bounds.min.x-.033)<.00001);assert.ok(bird.position.y<0&&bird.position.y>-.5/config.imageAspect,'bird must overlap lower-right star area');assert.ok(bird.position.x>.4);
const parent=new Group();parent.add(decorations);assert.equal(bird.parent.parent,parent,'bird belongs to panel transform');decorations.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});
console.log('PASS: right-upper bird size, edge overlap, shared panel transform');

const floating=createBirdDecoration(birdData,config.imageAspect);const floatBird=floating.children[0],base=floatBird.position.clone();
floating.userData.update(1);assert.ok(Math.abs(floatBird.position.y-base.y-.008)<1e-8);
floating.userData.update(3);assert.ok(Math.abs(floatBird.position.y-base.y+.008)<1e-8);
floating.userData.update(4);assert.ok(floatBird.position.distanceTo(base)<1e-8);assert.equal(floating.position.length(),0,'animation must not move the panel parent');
floating.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: gentle bird floating cycle and stationary parent');

const props={};for(const [key,file] of Object.entries({tallTree:'tall-tree',sparkles:'sparkles',greenTree:'green-tree',pinkBuilding:'pink-building-v2'}))props[key]=JSON.parse(await fs.readFile(new URL(`../dist/assets/${file}.json`,import.meta.url)));
const fullScene=createBirdDecoration({bird:birdData,props},config.imageAspect);
const leftTree=fullScene.getObjectByName('Tall tree at lower left'),rightBuilding=fullScene.getObjectByName('Pink building at lower right'),rightTree=fullScene.getObjectByName('Green tree behind building'),stars=fullScene.getObjectByName('Golden sparkles above building');
assert.ok(leftTree.position.x<-.5&&Math.abs(leftTree.position.y+.5/config.imageAspect)<1e-8);assert.ok(rightBuilding.position.x>0&&rightBuilding.position.y<0);assert.ok(rightTree.position.z<rightBuilding.position.z);assert.ok(stars.position.y>rightBuilding.position.y);
const propPositions=[leftTree,rightBuilding,rightTree,stars].map(o=>o.position.toArray());fullScene.userData.update(1);assert.deepEqual([leftTree,rightBuilding,rightTree,stars].map(o=>o.position.toArray()),propPositions,'only bird floats; corner props stay fixed');
fullScene.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: reference corner layout, tree behind building, stars above, fixed decorations');

const spinning=createBirdDecoration({bird:birdData,props},config.imageAspect);const starGroup=spinning.getObjectByName('Golden sparkles above building');
const centers=starGroup.children.map(o=>o.position.toArray());spinning.userData.update(2);
assert.ok(starGroup.children.every(o=>Math.abs(o.rotation.y)>0),'all stars rotate');assert.deepEqual(starGroup.children.map(o=>o.position.toArray()),centers,'stars rotate around their own centers');
spinning.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: individual star rotation with fixed centers');

const {SceneGestureState,attachSceneGestures}=await import('../dist/scene-gestures.mjs');
const touch=new SceneGestureState();touch.down(1,0,0);touch.move(1,50,25);assert.equal(touch.yaw,.4);assert.equal(touch.pitch,.2);
touch.down(2,150,25);const oldYaw=touch.yaw;touch.move(2,250,25);assert.equal(touch.scale,2);assert.equal(touch.yaw,oldYaw,'pinch must not add single-finger rotation');
touch.up(2);touch.move(1,50,25);assert.equal(touch.yaw,oldYaw,'lifting second finger must not jump');
touch.reset();touch.down(1,0,0);touch.down(2,100,0);touch.move(2,0,100);assert.ok(Math.abs(touch.roll+Math.PI/2)<1e-8);assert.equal(touch.scale,1);
touch.move(2,0,10000);assert.equal(touch.scale,2.5);touch.move(2,0,.1);assert.equal(touch.scale,.35);touch.up(2);touch.move(1,0,100000);assert.ok(touch.pitch<=Math.PI*.42);touch.clear();assert.equal(touch.move(1,99,99),false,'cancelled pointers cannot move scene');
const {createVideoPanel}=await import('../dist/video-panel.mjs');
const grouped=createVideoPanel({},config.imageAspect,{bird:birdData,props});grouped.root.position.set(2,3,-4);grouped.root.quaternion.setFromAxisAngle(new Vector3(0,1,0),.3);grouped.root.scale.setScalar(1.7);grouped.root.updateMatrixWorld();const anchorMatrix=grouped.root.matrixWorld.toArray();
touch.scale=1.4;touch.yaw=.5;touch.apply(grouped.content);grouped.root.updateMatrixWorld();assert.deepEqual(grouped.root.matrixWorld.toArray(),anchorMatrix,'gestures must never alter SLAM anchor');assert.ok(grouped.content.children.length>=5);assert.ok(grouped.content.getObjectByName('Pink building at lower right'));grouped.update(1);assert.equal(grouped.content.scale.x,1.4,'bird/star animation must not override user scale');
const handlers=new Map(),surface={addEventListener:(k,v)=>handlers.set(k,v),removeEventListener:k=>handlers.delete(k),setPointerCapture:()=>{},hasPointerCapture:()=>false};let enable=true;const controls=attachSceneGestures(surface,grouped.content,{enabled:()=>enable});const event={pointerId:1,clientX:0,clientY:0,pointerType:'touch',preventDefault:()=>{}};handlers.get('pointerdown')(event);handlers.get('pointermove')({...event,clientX:20});assert.notEqual(controls.state.yaw,0);enable=false;handlers.get('pointermove')({...event,clientX:40});assert.equal(controls.state.points.size,0);controls.reset();assert.equal(grouped.content.scale.x,1);assert.equal(grouped.content.quaternion.angleTo(new Quaternion()),0);controls.dispose();assert.equal(handlers.size,0);grouped.dispose();
console.log('PASS: one-finger rotation, pinch/twist, scale limits, pointer lifecycle, reset, unchanged world anchor and grouped animations');

const tapHandlers=new Map(),tapSurface={...surface,addEventListener:(k,v)=>tapHandlers.set(k,v),removeEventListener:k=>tapHandlers.delete(k)};let taps=0;const tapControls=attachSceneGestures(tapSurface,new Group(),{onTap:()=>taps++});
const fire=(type,id,x,y,time)=>tapHandlers.get(type)({type,pointerId:id,clientX:x,clientY:y,timeStamp:time,pointerType:'touch',preventDefault:()=>{}});
fire('pointerdown',1,10,10,0);fire('pointermove',1,12,11,50);fire('pointerup',1,12,11,100);assert.equal(taps,1,'tap with tiny jitter toggles once');
fire('pointerdown',1,10,10,200);fire('pointermove',1,40,10,250);fire('pointermove',1,10,10,270);fire('pointerup',1,10,10,300);assert.equal(taps,1,'drag returning to start must not toggle');
fire('pointerdown',1,10,10,400);fire('pointerdown',2,90,10,410);fire('pointerup',2,90,10,450);fire('pointerup',1,10,10,460);assert.equal(taps,1,'pinch/twist cannot toggle on final release');
fire('pointerdown',1,10,10,500);fire('pointercancel',1,10,10,550);assert.equal(taps,1);fire('pointerdown',1,10,10,600);fire('pointerup',1,10,10,1200);assert.equal(taps,1,'long press is not a tap');tapControls.dispose();
const {videoFaceHit}=await import('../dist/scene-gestures.mjs');const testPanel=createVideoPanel({},4/3),testCamera=new PerspectiveCamera(37,1,.01,20);testCamera.position.set(0,0,2);testCamera.lookAt(0,0,0);const testSurface={getBoundingClientRect:()=>({left:0,top:0,width:400,height:400})};
assert.equal(videoFaceHit(testSurface,testPanel.front,testCamera,200,200),true);assert.equal(videoFaceHit(testSurface,testPanel.front,testCamera,5,5),false,'blank background must not pause video');testPanel.content.rotation.y=.6;testPanel.content.scale.setScalar(.8);assert.equal(videoFaceHit(testSurface,testPanel.front,testCamera,200,200),true,'video picking follows group rotation and scale');testPanel.dispose();
console.log('PASS: tap vs jitter/drag/multi-touch/cancel/long press, blank background rejection and transformed video hit testing');

const trainData=JSON.parse(await fs.readFile(new URL('../dist/assets/steam-train.json',import.meta.url),'utf8'));
const trainScene=createBirdDecoration({bird:birdData,props:{...props,steamTrain:trainData}},config.imageAspect);
const movingTrain=trainScene.getObjectByName('Looping steam train');
trainScene.userData.update(100);const startX=movingTrain.position.x;
trainScene.userData.update(104);assert.ok(movingTrain.visible&&movingTrain.position.x>startX);
trainScene.userData.update(108.1);assert.equal(movingTrain.visible,false);
trainScene.userData.update(108.4);assert.ok(movingTrain.visible);assert.ok(Math.abs(movingTrain.position.x-startX)<1e-8);
trainScene.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: train moves right, disappears at building and restarts at origin');


