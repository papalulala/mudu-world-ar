import assert from 'node:assert/strict';
import {SpatialPlacement} from '../dist/anchor-state.mjs';
import {Vector3,Quaternion,PerspectiveCamera,Group} from '../dist/vendor/three.module.js';
import fs from 'node:fs/promises';
const config=JSON.parse(await fs.readFile(new URL('../dist/assets/world-config.json',import.meta.url)));
const detail={name:config.targetName,position:{x:1,y:1.8,z:-2},rotation:{x:0,y:0,z:0,w:1},scale:1,scaledWidth:.75,scaledHeight:1};
const placement=new SpatialPlacement(config);
for(let i=0;i<30;i++)assert.equal(placement.ingest(detail,i*80,false),false,'image detection alone must not lock without normal SLAM tracking');
assert.equal(placement.locked,false);
placement.reset();
for(let i=0;i<12;i++)placement.ingest(detail,i*90,true);
assert.equal(placement.locked,true,'a stable image pose with valid world tracking must lock');
const before=placement.pose.position.toArray();const beforeRotation=placement.pose.rotation.toArray();
placement.markerLost();assert.equal(placement.markerVisible,false);assert.equal(placement.locked,true);
assert.deepEqual(placement.pose.position.toArray(),before,'losing the image must preserve the world anchor');
placement.ingest({...detail,position:{x:50,y:30,z:10}},3000,true);
assert.deepEqual(placement.pose.position.toArray(),before,'reacquiring or moving the marker must not drag a locked panel');
assert.deepEqual(placement.pose.rotation.toArray(),beforeRotation);
const board=new Group();board.position.copy(placement.pose.position);board.quaternion.copy(placement.pose.rotation);board.updateMatrixWorld();
const world=board.matrixWorld.toArray();const camera=new PerspectiveCamera(50,1.3,.01,100);camera.position.set(0,2,1);camera.lookAt(board.position);camera.updateMatrixWorld();
const pointA=board.position.clone().project(camera);camera.position.x+=1;camera.lookAt(board.position.clone().add(new Vector3(.3,0,0)));camera.updateMatrixWorld();const pointB=board.position.clone().project(camera);
assert.notDeepEqual(pointA.toArray(),pointB.toArray(),'moving the camera must change the view of the board');
assert.deepEqual(board.matrixWorld.toArray(),world,'camera movement must not move the world anchor');
placement.reset();assert.equal(placement.locked,false);assert.equal(placement.pose,null);
placement.ingest({...detail,scale:0},0,true);assert.equal(placement.samples,0,'invalid target poses must not lock');
console.log('PASS: stable lock, no lock without SLAM, persistence after marker loss, no marker-follow after lock, camera perspective, reset, invalid input');

const {MultiImagePlacement}=await import('../dist/anchor-state.mjs');
const multi=new MultiImagePlacement(config);
for(const t of config.targets){
 multi.reset();const d={...detail,name:t.targetName};
 for(let i=0;i<12;i++)multi.ingest(d,i*90,true);
 assert.equal(multi.locked,true,`${t.targetName} must lock`);
 const fixed=multi.pose.position.toArray();
 const other=config.targets.find(x=>x.targetName!==t.targetName);
 multi.ingest({...d,name:other.targetName,position:{x:99,y:99,z:99}},2000,true);
 multi.markerLost(t.targetName);
 assert.deepEqual(multi.pose.position.toArray(),fixed,'other image and image loss must preserve lock');
}
multi.reset();multi.ingest(detail,0,true);
multi.markerLost('mudu-poster');assert.equal(multi.samples,1,'unrelated image loss must not reset active image');
multi.ingest({...detail,name:'mudu-poster'},90,true);assert.equal(multi.samples,1,'switching images must restart stability samples');
console.log('PASS: both image targets, independent stability, first stable image keeps world anchor');

const {createBirdDecoration}=await import('../dist/bird-decoration.mjs');
const birdData=JSON.parse(await fs.readFile(new URL('../dist/assets/white-bird.json',import.meta.url)));
const decorations=createBirdDecoration(birdData,config.imageAspect);const bird=decorations.children[0];
const {Box3}=await import('../dist/vendor/three.module.js');
const bounds=new Box3().setFromObject(bird);assert.ok(Math.abs(bounds.max.x-bounds.min.x-.11)<.00001);assert.ok(bounds.min.y<.5/config.imageAspect&&bounds.max.y>.5/config.imageAspect,'bird must straddle top-right panel edge');assert.ok(bird.position.x>.4);
const parent=new Group();parent.add(decorations);assert.equal(bird.parent.parent,parent,'bird belongs to panel transform');decorations.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});
console.log('PASS: right-upper bird size, edge overlap, shared panel transform');

const floating=createBirdDecoration(birdData,config.imageAspect);const floatBird=floating.children[0],base=floatBird.position.clone();
floating.userData.update(1);assert.ok(Math.abs(floatBird.position.y-base.y-.008)<1e-8);
floating.userData.update(3);assert.ok(Math.abs(floatBird.position.y-base.y+.008)<1e-8);
floating.userData.update(4);assert.ok(floatBird.position.distanceTo(base)<1e-8);assert.equal(floating.position.length(),0,'animation must not move the panel parent');
floating.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: gentle bird floating cycle and stationary parent');

const props={};for(const [key,file] of Object.entries({tallTree:'tall-tree',sparkles:'sparkles',greenTree:'green-tree',pinkBuilding:'pink-building'}))props[key]=JSON.parse(await fs.readFile(new URL(`../dist/assets/${file}.json`,import.meta.url)));
const fullScene=createBirdDecoration({bird:birdData,props},config.imageAspect);
const leftTree=fullScene.getObjectByName('Tall tree at lower left'),rightBuilding=fullScene.getObjectByName('Pink building at lower right'),rightTree=fullScene.getObjectByName('Green tree behind building'),stars=fullScene.getObjectByName('Golden sparkles above building');
assert.ok(leftTree.position.x<-.5&&leftTree.position.y<0);assert.ok(rightBuilding.position.x>0&&rightBuilding.position.y<0);assert.ok(rightTree.position.z<rightBuilding.position.z);assert.ok(stars.position.y>rightBuilding.position.y);
const propPositions=[leftTree,rightBuilding,rightTree,stars].map(o=>o.position.toArray());fullScene.userData.update(1);assert.deepEqual([leftTree,rightBuilding,rightTree,stars].map(o=>o.position.toArray()),propPositions,'only bird floats; corner props stay fixed');
fullScene.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: reference corner layout, tree behind building, stars above, fixed decorations');

const spinning=createBirdDecoration({bird:birdData,props},config.imageAspect);const starGroup=spinning.getObjectByName('Golden sparkles above building');
const centers=starGroup.children.map(o=>o.position.toArray());spinning.userData.update(2);
assert.ok(starGroup.children.every(o=>Math.abs(o.rotation.y)>0),'all stars rotate');assert.deepEqual(starGroup.children.map(o=>o.position.toArray()),centers,'stars rotate around their own centers');
spinning.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});console.log('PASS: individual star rotation with fixed centers');
